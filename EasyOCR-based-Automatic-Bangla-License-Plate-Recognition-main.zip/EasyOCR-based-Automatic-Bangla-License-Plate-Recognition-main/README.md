This is basically an experiment with Bangla Character based License plate. Applied EasyOCR, and checking that it is working for bangla character or not. Bacause previously it didn't worked for bangla characters. So now it's working nicely. 

Here it is working and detecting with image. 

Based on pre-trained tflite model

The next work will be detecting from any angle, distance, real time.
